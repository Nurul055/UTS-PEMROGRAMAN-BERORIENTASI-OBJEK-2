package kasirakademik;

public class Tagihan {
    private String id;
    private Mahasiswa mahasiswa;
    private String semester;
    private double total;

    public Tagihan(String id, Mahasiswa mahasiswa, String semester, double total) {
        this.id = id;
        this.mahasiswa = mahasiswa;
        this.semester = semester;
        this.total = total;
    }

    public String getId() {
        return id;
    }

    public Mahasiswa getMahasiswa() {
        return mahasiswa;
    }

    public double getTotal() {
        return total;
    }

    public String getSemester() {
        return semester;
    }
}
