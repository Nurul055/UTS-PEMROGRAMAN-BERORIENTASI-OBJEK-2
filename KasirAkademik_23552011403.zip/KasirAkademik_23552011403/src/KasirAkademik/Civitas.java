package kasirakademik;

public abstract class Civitas {
    protected String nama;
    protected String id;

    public Civitas(String id, String nama) {
        this.id = id;
        this.nama = nama;
    }

    public String getNama() {
        return nama;
    }

    public String getId() {
        return id;
    }

    public abstract void tampilkanInfo();
}
