package kasirakademik;

public class Dosen extends Civitas {
    private String nidn;
    private String matakuliah;

    public Dosen(String id, String nama, String nidn, String matakuliah) {
        super(id, nama);
        this.nidn = nidn;
        this.matakuliah = matakuliah;
    }

    public String getNidn() {
        return nidn;
    }

    public String getMatakuliah() {
        return matakuliah;
    }

    @Override
    public void tampilkanInfo() {
        System.out.println("Dosen: " + nama + " (NIDN: " + nidn + ", Mata Kuliah: " + matakuliah + ")");
    }
}
