package kasirakademik;

import java.time.LocalDate;

public class Transaksi {
    private String id;
    private Tagihan tagihan;
    private double jumlahBayar;
    private LocalDate tanggal;

    public Transaksi(String id, Tagihan tagihan, double jumlahBayar) {
        this.id = id;
        this.tagihan = tagihan;
        this.jumlahBayar = jumlahBayar;
        this.tanggal = LocalDate.now();
    }

    public void cetakStruk() {
        System.out.println("====== STRUK PEMBAYARAN ======");
        System.out.println("Tanggal       : " + tanggal);
        System.out.println("Mahasiswa     : " + tagihan.getMahasiswa().getNama());
        System.out.println("NIM           : " + tagihan.getMahasiswa().getNim());
        System.out.println("Semester      : " + tagihan.getSemester());
        System.out.println("Total Tagihan : " + tagihan.getTotal());
        System.out.println("Jumlah Bayar  : " + jumlahBayar);
        System.out.println("Status        : " + (jumlahBayar >= tagihan.getTotal() ? "Lunas" : "Belum Lunas"));
        System.out.println("===============================");
    }
}
