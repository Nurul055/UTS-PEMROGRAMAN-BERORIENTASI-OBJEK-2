package kasirakademik;

public class Mahasiswa extends Civitas {
    private String nim;
    private String semester;

    public Mahasiswa(String id, String nama, String nim, String semester) {
        super(id, nama);
        this.nim = nim;
        this.semester = semester;
    }

    public String getNim() {
        return nim;
    }

    public String getSemester() {
        return semester;
    }

    @Override
    public void tampilkanInfo() {
        System.out.println("Mahasiswa: " + nama + " (NIM: " + nim + ", Semester: " + semester + ")");
    }
}
