package kasirakademik;

public class Main {
    public static void main(String[] args) {
        // ==== Mahasiswa ====
        Mahasiswa mhs = new Mahasiswa("1", "Ai Nurul Hidayah", "23552011403", "Genap");
        mhs.tampilkanInfo();

        // ==== Dosen ====
        Dosen dosen = new Dosen("2", "Pak Dedi", "101010", "Pemrograman Berorientasi Objek");
        dosen.tampilkanInfo();

        // ==== Pembayaran Tagihan Mahasiswa ====
        Pembayaran pembayaran = new Pembayaran();
        double totalTagihan = pembayaran.hitungTagihan(mhs.getSemester());
        Tagihan tagihan = new Tagihan("T001", mhs, mhs.getSemester(), totalTagihan);

        // ==== Transaksi ====
        Transaksi transaksi = new Transaksi("TR001", tagihan, 5500000); // sesuai semester Genap
        transaksi.cetakStruk();
    }
}
