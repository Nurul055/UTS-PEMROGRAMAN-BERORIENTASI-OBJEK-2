package kasirakademik;

public class Pembayaran {
    public double hitungTagihan(String semester) {
        if (semester.equalsIgnoreCase("Ganjil")) {
            return 5000000;
        } else if (semester.equalsIgnoreCase("Genap")) {
            return 5500000;
        } else {
            return 0;
        }
    }
}
